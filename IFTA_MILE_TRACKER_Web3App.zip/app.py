# Flask app placeholder
from flask import Flask
app = Flask(__name__)

@app.route('/')
def home():
    return 'IFTA MILE TRACKER - Web App'